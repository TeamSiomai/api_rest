<?php

$host = "localhost";
$user = "zerterra";
$pass = "zerterra";
$db = "crud_android";

$con = mysqli_connect($host,$user,$pass, $db);

// if($con){
//   echo "Koneksi Berhasil";
// }else{
//   echo "gagal";
// }

 ?>
